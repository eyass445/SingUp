//
//  ViewController.swift
//  MyCostomMessage
//
//  Created by eyas seyam on 5/3/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import UIKit

class MyCostomMessageVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        Labil.text = Messega
    }

    var Messega : String!
    
    @IBOutlet weak var BigView: UIView! {
        didSet {
            BigView.layer.cornerRadius = 10
            BigView.layer.borderColor = UIColor.yellow.cgColor
            BigView.layer.borderWidth = 1
        }
    }
    
    @IBOutlet weak var Labil: UILabel!
    
    
    @IBOutlet weak var Button: UIButton!   {
        didSet {
    
       Button.layer.cornerRadius = 10
   
    }
}
    
    @IBAction func ButtonOk(_ sender: UIButton) {
        
        dismiss(animated: true, completion: nil)
        
    }
    
}



class MessageBox {
    
    
    static func Show (Message : String , MyVC : UIViewController) {
        
        let StoryBord = UIStoryboard(name: "MessageStBo", bundle: nil)
        let VC  = StoryBord.instantiateViewController(withIdentifier: "MyCostomMessageVC") as! MyCostomMessageVC
        
        VC.modalTransitionStyle = .crossDissolve
        VC.modalPresentationStyle = .overFullScreen
        
        
        VC.Messega = Message
        MyVC.present(VC, animated: true, completion: nil)
    }
}


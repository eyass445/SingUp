//
//  ViewController.swift
//  SingUp
//
//  Created by eyas seyam on 5/2/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import UIKit
import FirebaseAuth



class ViewController: UIViewController  , UIImagePickerControllerDelegate , UINavigationControllerDelegate {
    
    
    
    override var prefersStatusBarHidden: Bool {return true}
    
    @IBOutlet weak var TopLayoutImageView: NSLayoutConstraint!
    
    @IBOutlet weak var doneLayoutimag: NSLayoutConstraint!
    
    @IBOutlet weak var imageViweHight: NSLayoutConstraint!
    
    @IBOutlet weak var formGetStarted: NSLayoutConstraint!
    
    @IBOutlet weak var botomGetStarted: NSLayoutConstraint!
    
    @IBOutlet var TextFildS: [UITextField]!
    
    @IBOutlet weak var imageViiwe: UIImageView!
    
    let ImagePicker = UIImagePickerController()
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {  view.endEditing(true) }


    @IBOutlet weak var EmailTextFileld: UITextField!
    
    
    @IBOutlet weak var PasswordTextField: UITextField!
    
    
    @IBOutlet weak var ConfirmPass: UITextField!
    
    
    @IBAction func GetStartedAtion(_ sender: UIButton) {
        
        if PasswordTextField.text != ConfirmPass.text {
            MessageBox.Show(Message: "كلمة المرور غير متطابقة", MyVC: self)
            return
        }
        
        Auth.auth().createUser(withEmail: EmailTextFileld.text!, password: PasswordTextField.text!) { (User, Error) in
            if Error == nil {
                print(self.EmailTextFileld)
                print("done")
                self.performSegue(withIdentifier: "Next", sender: nil)
            }
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        SetUpKeybordNotification ()
        
        for one in TextFildS {
            one.delegate = self
        }
        
        SettingUPimageView()
       
    }
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}


/////////////////////////////////////////////////////////////////////////////


// ChoesePhoto

extension ViewController {
    
    
    func SettingUPimageView () {
        
        ImagePicker.delegate = self
        ImagePicker.sourceType = .photoLibrary
        ImagePicker.allowsEditing = true
        
        
        let TapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ViewController.ChoesePhoto) )
        imageViiwe.isUserInteractionEnabled = true
        imageViiwe.addGestureRecognizer(TapGestureRecognizer)
        
        
        
        
    }
    
    
    
    public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let TheImage = info[UIImagePickerController.InfoKey.editedImage] as! UIImage
        imageViiwe.image = TheImage
        dismiss(animated: true, completion: nil)
        
    }
    
    public func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        
        dismiss(animated: true, completion: nil)
        
    }
    
    
    
    
    @objc func ChoesePhoto(){
        
        let Alert = UIAlertController(title: "اختر مصدر الصورة ", message: "من اي مصدر تريد احضار الصورة ؟ ", preferredStyle: .actionSheet)
        
        let camera = UIAlertAction(title: "الكاميرا ", style: .default) { [weak self ] (ـ) in
            self?.ImagePicker.sourceType = .camera
            if self != nil {
                self?.present(self!.ImagePicker, animated: true, completion: nil)
                
            }
        }
        
        
        let photoLibrary = UIAlertAction(title: "الصور ", style: .default) { [weak self ] (ـ) in
            self?.ImagePicker.sourceType = .photoLibrary
            if self != nil {
                self?.present(self!.ImagePicker, animated: true, completion: nil)
                
            }
        }
        
        let cancel = UIAlertAction(title: "الغاء ", style: .cancel, handler: nil)
        
        Alert.addAction(camera)
        Alert.addAction(cancel)
        Alert.addAction(photoLibrary)
        present(Alert, animated: true, completion: nil)
        
    }
    
    
    
}

/////////////////////////////////////////////////////////////////////////////




// TextFieldDelegate
extension ViewController : UITextFieldDelegate {
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        for one in TextFildS {
            if one.tag == textField.tag + 1 {
                one.becomeFirstResponder()
            }
        }
        return true
    }
    
  
    
}


/////////////////////////////////////////////////////////////////////////////


// Animation
extension ViewController {
    
    
   
    
    
    func StartAnimation (KeybordHeight : CGFloat ){
        TopLayoutImageView.constant = 0
        imageViweHight.constant = 0
        doneLayoutimag.constant = 30
        formGetStarted.constant = KeybordHeight
        botomGetStarted.constant = 30
        UIView.animate(withDuration: 0.2 ) { self.view.layoutIfNeeded()}
    }
    
    
    
    func EndAnimation () {
        
        TopLayoutImageView.constant = 50
        imageViweHight.constant = 100
        doneLayoutimag.constant = 50
        formGetStarted.constant = 27
        botomGetStarted.constant = 31
        UIView.animate(withDuration: 0.2 ) { self.view.layoutIfNeeded()}
        
        
    }
    
}

/////////////////////////////////////////////////////////////////////////////


// Keybord
extension ViewController {
    
    func SetUpKeybordNotification () {
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.KeyboardDidShow(Notification : )), name: UIResponder.keyboardDidShowNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.KeyboardDidHide(Notification:)), name: UIResponder.keyboardDidHideNotification, object: nil)
        
        
    }
    
    @objc func KeyboardDidShow (Notification : NSNotification) {
        
        guard let Dic = Notification.userInfo as? [String : AnyObject] else { return }
        guard let KeyboardSize = Dic[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect else { return }
        StartAnimation(KeybordHeight: KeyboardSize.height)
        
    }
    
    @objc func KeyboardDidHide (Notification : NSNotification) {
        EndAnimation()
        
    }
    
    
}

/////////////////////////////////////////////////////////////////////////////

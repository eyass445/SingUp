//
//  SignInVCViewController.swift
//  SingUp
//
//  Created by eyas seyam on 5/2/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import UIKit
import FirebaseAuth

class SignInVC: UIViewController {

    @IBOutlet weak var butomLayout: NSLayoutConstraint!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       SetUpKeybordNotification()
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {  view.endEditing(true) }


  
    @IBAction func ToSignUp(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    
    
    
    @IBOutlet weak var EmailTextField: UITextField!
    
    
    @IBOutlet weak var PasswordTextField: UITextField!
    
    
    
    
    @IBAction func SignInAction(_ sender: UIButton) {
        
        Auth.auth().signIn(withEmail: EmailTextField.text!, password: PasswordTextField.text!) { (User,  Error) in
            if Error == nil {
                self.performSegue(withIdentifier: "Nextt", sender: nil)
            } else {
                MessageBox.Show(Message: Error!.localizedDescription, MyVC: self)
                
            }
        }
    }
    
    
    
    
}
//Keybord
extension SignInVC {

    
    
    func SetUpKeybordNotification () {


        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.KeyboardDidShow(Notification : )), name: UIResponder.keyboardDidShowNotification, object: nil)

        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.KeyboardDidHide(Notification:)), name: UIResponder.keyboardDidHideNotification, object: nil)

       
    }
    
    
   @objc func KeyboardDidShow (Notification : NSNotification) {
        
        guard let Dic = Notification.userInfo as? [String : AnyObject] else { return }
        guard let KeyboardSize = Dic[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect else { return }
        
        butomLayout.constant = KeyboardSize.height - 120
        
        UIView.animate(withDuration: 0.2) {  self.view.layoutIfNeeded() }
        
    }
    
  @objc  func KeyboardDidHide (Notification : NSNotification) {
        
        butomLayout.constant = 161
        
        UIView.animate(withDuration: 0.2) { self.view.layoutIfNeeded() }
        
    }



}

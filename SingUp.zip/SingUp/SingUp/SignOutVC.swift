//
//  SignOutVC.swift
//  SingUp
//
//  Created by eyas seyam on 5/2/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import UIKit
import FirebaseAuth

class SignOutVC: UIViewController {
    
    
    
   
    
    @IBAction func SignOut(_ sender: UIButton) {
        
        
        try? Auth.auth().signOut()
        dismiss(animated: true, completion: nil)
        
        
    }
    
    
}

//
//  ResetpassVC.swift
//  SingUp
//
//  Created by eyas seyam on 5/3/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import UIKit
import FirebaseAuth

class ResetpassVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {  view.endEditing(true) }


    @IBOutlet weak var ResetPassTF: UITextField!
    
    @IBAction func ResetPassButtonACT(_ sender: UIButton) {
        Auth.auth().sendPasswordReset(withEmail: ResetPassTF.text!) { (Error) in
            if Error != nil {
                MessageBox.Show(Message: "هذا الايميل غير مسجل ", MyVC: self)
                
            } else {
                MessageBox.Show(Message: "تم ارسال رسالة الى الايميل للتآكيد", MyVC: self)
            }
        }
        
    }
    
    
    @IBAction func SignINButtonAUT(_ sender: UIButton) {
        
        dismiss(animated: true, completion: nil)
    }
}

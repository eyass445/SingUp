//
//  CastamBut.swift
//  Timer
//
//  Created by eyas seyam on 3/11/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import UIKit

extension UIView {

    @IBInspectable var BorderWhith : CGFloat  {
        set {
            self.layer.borderWidth = newValue
        } get {
            return self.layer.borderWidth
        }
    }
    
    
    @IBInspectable var BorderColor : UIColor  {
        get {
            return UIColor(cgColor: self.layer.borderColor! )
        } set {
            self.layer.borderColor = newValue.cgColor
        }
    }
    
    
    @IBInspectable var CornarRaduis : CGFloat  {
        get {
            return self.layer.cornerRadius
        } set {
             self.layer.cornerRadius = newValue
        }
    }
    
    
   
}

extension UITextField {
    
    
    @IBInspectable var PlaseHolderColor :UIColor {
        
        get {
            return self.PlaseHolderColor
        } set {
            self.attributedPlaceholder = NSAttributedString(string: self.placeholder != nil ? self.placeholder! :  "", attributes: [NSAttributedString.Key.foregroundColor : newValue ])
            
        }
    }
    
    
}
